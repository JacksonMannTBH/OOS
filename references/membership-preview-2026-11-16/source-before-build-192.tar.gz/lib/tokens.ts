// Canonical design tokens. Mirror in app/globals.css and tailwind.config.ts
// when Tailwind utilities need the same semantic color.
export const SS_TOKENS = {
  bg0: "var(--ss-bg0)",
  bg1: "var(--ss-bg1)",
  bg2: "var(--ss-bg2)",
  bg3: "var(--ss-bg3)",
  fg0: "var(--ss-fg0)",
  fg1: "var(--ss-fg1)",
  fg2: "var(--ss-fg2)",
  fg3: "var(--ss-fg3)",
  alert: "var(--ss-alert)",
  alertDim: "var(--ss-alert-dim)",
  warn: "var(--ss-warn)",
  warnDim: "var(--ss-warn-dim)",
  danger: "var(--ss-danger)",
  clear: "var(--ss-clear)",
  clearDim: "var(--ss-clear-dim)",
  sky: "var(--ss-sky)",
  skyDim: "var(--ss-sky-dim)",
  hairline: "var(--ss-hairline)",
  hairline2: "var(--ss-hairline-2)",
  surface: "var(--ss-surface)",
  surfaceTranslucent: "var(--ss-surface-translucent)",
  shadowSm: "var(--ss-shadow-sm)",
  shadowMd: "var(--ss-shadow-md)",
  shadowLg: "var(--ss-shadow-lg)",
  radiusSm: "var(--ss-radius-sm)",
  radiusMd: "var(--ss-radius-md)",
  radiusLg: "var(--ss-radius-lg)",
  radiusXl: "var(--ss-radius-xl)",
} as const;

export type SSToken = keyof typeof SS_TOKENS;
