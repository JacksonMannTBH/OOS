import { getSupabaseAdmin } from "@/lib/supabase/server";
import { aircraftVehicleType } from "@/lib/aircraft-type";
import { sendAircraftAlertPush } from "./web-push";
import { sendAircraftAlertFcm } from "./fcm";
import { isTakeoffDeliverySelected } from "./eligibility";
import { mapWithConcurrency } from "../map-with-concurrency";

const MAX_DELIVERIES_PER_RUN = 100;
const NOTIFICATION_TAG_WINDOW_MS = 30 * 60 * 1_000;

export type NotificationDispatchSummary = {
  claimed: number;
  sent: number;
  failed: number;
  expired: number;
  skipped: number;
};

export async function dispatchPendingTakeoffNotifications(options: { maxDurationMs?: number } = {}): Promise<NotificationDispatchSummary> {
  const deadline = Date.now() + (options.maxDurationMs ?? Number.POSITIVE_INFINITY);
  const db = getSupabaseAdmin();
  const now = new Date().toISOString();
  const { data: deliveries, error } = await db
    .from("notification_deliveries")
    .select(
      "id,attempt_count,notification_events(state_code,payload,occurred_at),push_endpoints(id,endpoint,transport,p256dh,auth)",
    )
    .in("status", ["pending", "failed"])
    .lte("next_attempt_at", now)
    .order("created_at")
    .limit(MAX_DELIVERIES_PER_RUN);
  if (error) throw new Error(`Notification queue read failed: ${error.message}`);

  const summary: NotificationDispatchSummary = {
    claimed: 0,
    sent: 0,
    failed: 0,
    expired: 0,
    skipped: 0,
  };

  await mapWithConcurrency(deliveries ?? [], 4, async delivery => {
    // Leave unclaimed rows for the next tick before the Edge Function deadline.
    if (Date.now() >= deadline) return;
    const claimToken = crypto.randomUUID();
    const { data: claimed } = await db
      .from("notification_deliveries")
      .update({
        status: "processing",
        claimed_at: now,
        claim_token: claimToken,
        attempt_count: Number(delivery.attempt_count ?? 0) + 1,
        updated_at: now,
      })
      .eq("id", delivery.id)
      .in("status", ["pending", "failed"])
      .select("id")
      .maybeSingle();
    if (!claimed) return;
    summary.claimed += 1;

    const event = Array.isArray(delivery.notification_events)
      ? delivery.notification_events[0]
      : delivery.notification_events;
    const endpoint = Array.isArray(delivery.push_endpoints)
      ? delivery.push_endpoints[0]
      : delivery.push_endpoints;
    if (!event || !endpoint) {
      await markFailed(String(delivery.id), claimToken, "missing_related_record", 15);
      summary.failed += 1;
      return;
    }
    const payload = (event.payload ?? {}) as Record<string, unknown>;
    const tail = String(payload.tail ?? "Aircraft");
    // Recheck immediately before sending so queued/retried alerts respect edits.
    const { data: preferences, error: preferenceError } = await db
      .from("notification_subscriptions")
      .select("enabled,state_code,excluded_aircraft_by_state,push_endpoints(enabled)")
      .eq("push_endpoint_id", endpoint.id)
      .maybeSingle();
    if (preferenceError) {
      await markFailed(String(delivery.id), claimToken, "preference_read_failed", 2);
      summary.failed += 1;
      return;
    }
    const currentEndpoint = Array.isArray(preferences?.push_endpoints)
      ? preferences.push_endpoints[0]
      : preferences?.push_endpoints;
    if (!preferences || !currentEndpoint?.enabled || !isTakeoffDeliverySelected({
      enabled: Boolean(preferences.enabled),
      stateCode: String(preferences.state_code),
      excludedAircraftByState: preferences.excluded_aircraft_by_state,
    }, event.state_code, tail)) {
      await db.from("notification_deliveries").update({
        status: "expired",
        failure_reason: "not_selected_for_tracking",
        updated_at: new Date().toISOString(),
      }).eq("id", delivery.id).eq("claim_token", claimToken);
      summary.skipped += 1;
      return;
    }
    const notificationCopy = takeoffNotificationCopy(tail, payload.model);
    const detailUrl = `/map?tail=${encodeURIComponent(tail)}`;
    const pushPayload = {
        title: notificationCopy.title,
        body: notificationCopy.body,
        url: detailUrl,
        tag: takeoffNotificationTag(tail, event.occurred_at),
        aircraftTail: tail,
      };
    const result = endpoint.transport === "fcm"
      ? await sendAircraftAlertFcm(String(endpoint.endpoint), pushPayload)
      : await sendAircraftAlertPush(
          {
            transport: "web_push",
            endpoint: String(endpoint.endpoint),
            keys: {
              p256dh: String(endpoint.p256dh),
              auth: String(endpoint.auth),
            },
          },
          pushPayload,
        );

    if (result.ok) {
      await db
        .from("notification_deliveries")
        .update({
          status: "sent",
          sent_at: new Date().toISOString(),
          response_status: 201,
          failure_reason: null,
          updated_at: new Date().toISOString(),
        })
        .eq("id", delivery.id)
        .eq("claim_token", claimToken);
      await db
        .from("push_endpoints")
        .update({ last_success_at: new Date().toISOString() })
        .eq("id", endpoint.id);
      summary.sent += 1;
      return;
    }

    if (result.reason === "expired") {
      await db
        .from("notification_deliveries")
        .update({
          status: "expired",
          response_status: result.statusCode ?? null,
          failure_reason: "expired_subscription",
          updated_at: new Date().toISOString(),
        })
        .eq("id", delivery.id)
        .eq("claim_token", claimToken);
      await db
        .from("push_endpoints")
        .update({
          enabled: false,
          disabled_at: new Date().toISOString(),
          last_failure_at: new Date().toISOString(),
        })
        .eq("id", endpoint.id);
      summary.expired += 1;
      return;
    }

    await markFailed(
      String(delivery.id),
      claimToken,
      result.reason,
      Math.min(60, 2 ** (Number(delivery.attempt_count ?? 0) + 1)),
      result.statusCode,
    );
    summary.failed += 1;
  });
  return summary;
}

export function takeoffNotificationTag(
  tail: string,
  occurredAt: unknown,
): string {
  const normalizedTail = tail.trim().toUpperCase().replace(/[^A-Z0-9-]/g, "");
  const occurredMs = typeof occurredAt === "string"
    ? Date.parse(occurredAt)
    : NaN;
  const windowMs = Number.isFinite(occurredMs)
    ? Math.floor(occurredMs / NOTIFICATION_TAG_WINDOW_MS) *
      NOTIFICATION_TAG_WINDOW_MS
    : 0;
  return `takeoff-${normalizedTail || "AIRCRAFT"}-${windowMs}`;
}

export function takeoffNotificationCopy(tail: string, model: unknown) {
  const vehicleType = aircraftVehicleType(
    typeof model === "string" ? model : null,
  );

  return {
    title: vehicleType === "Helicopter" ? "Heli Above" : "Plane Above",
    body: `${tail} took flight`,
  };
}

async function markFailed(
  deliveryId: string,
  claimToken: string,
  reason: string,
  retryMinutes: number,
  statusCode?: number,
): Promise<void> {
  await getSupabaseAdmin()
    .from("notification_deliveries")
    .update({
      status: "failed",
      next_attempt_at: new Date(Date.now() + retryMinutes * 60_000).toISOString(),
      response_status: statusCode ?? null,
      failure_reason: reason,
      updated_at: new Date().toISOString(),
    })
    .eq("id", deliveryId)
    .eq("claim_token", claimToken);
}
