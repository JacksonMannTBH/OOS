"use client";

import { useEffect } from "react";
import { STATE_CHANGE_EVENT, STATE_PREFERENCE_KEY } from "@/lib/app-states";
import { AIRCRAFT_TRACKING_CHANGE_EVENT, AIRCRAFT_TRACKING_STORAGE_KEY } from "@/lib/aircraft-tracking";
import { AIRCRAFT_ALERT_PREFERENCE_SYNC_EVENT, syncAircraftAlertPreferences } from "@/lib/aircraft-alerts/client";
import { CALIFORNIA_REGION_EVENT, CALIFORNIA_REGION_KEY } from "@/lib/california-regions";

// Keep server notifications in sync even after leaving the settings page.
export function AircraftAlertPreferenceSync() {
  useEffect(() => {
    const sync = () => {
      void syncAircraftAlertPreferences({})
        .then((status) => window.dispatchEvent(new CustomEvent(AIRCRAFT_ALERT_PREFERENCE_SYNC_EVENT, { detail: { status } })))
        .catch(() => window.dispatchEvent(new CustomEvent(AIRCRAFT_ALERT_PREFERENCE_SYNC_EVENT, { detail: { error: true } })));
    };
    const onStorage = (event: StorageEvent) => {
      if (event.key === null || event.key === AIRCRAFT_TRACKING_STORAGE_KEY || event.key === STATE_PREFERENCE_KEY || event.key === CALIFORNIA_REGION_KEY) sync();
    };
    const onVisible = () => { if (document.visibilityState === "visible") sync(); };
    window.addEventListener("oos:pro-tier-changed", sync);
    window.addEventListener(STATE_CHANGE_EVENT, sync);
    window.addEventListener(AIRCRAFT_TRACKING_CHANGE_EVENT, sync);
    window.addEventListener(CALIFORNIA_REGION_EVENT, sync);
    window.addEventListener("storage", onStorage);
    window.addEventListener("online", sync);
    document.addEventListener("visibilitychange", onVisible);
    sync();
    return () => {
      window.removeEventListener("oos:pro-tier-changed", sync);
      window.removeEventListener(STATE_CHANGE_EVENT, sync);
      window.removeEventListener(AIRCRAFT_TRACKING_CHANGE_EVENT, sync);
      window.removeEventListener(CALIFORNIA_REGION_EVENT, sync);
      window.removeEventListener("storage", onStorage);
      window.removeEventListener("online", sync);
      document.removeEventListener("visibilitychange", onVisible);
    };
  }, []);
  return null;
}
