"use client";
import { openPro } from "@/lib/pro-access";
import { usePro } from "@/lib/hooks/usePro";
import { getMapOpeningCamera } from "@/lib/map-opening-camera";
import { MapHeadingCone } from "./MapHeadingCone";
import { watchDevicePosition } from "@/lib/device-location";
import { setAutomaticallyDetectedCaliforniaRegion } from "@/lib/california-regions";

import { useEffect, useMemo, useRef, useState } from "react";
import nextDynamic from "next/dynamic";
import Link from "next/link";
import type { Map as MaplibreMap } from "maplibre-gl";
import { useAircraft } from "@/lib/hooks/useAircraft";
import { useNationwideMapEnabled } from "@/lib/hooks/useNationwideMapEnabled";
import { useNationwideMapAircraft } from "@/lib/hooks/useNationwideMapAircraft";
import { mergeMapAircraft } from "@/lib/nationwide-map";
import { usePoliceSightings } from "@/lib/hooks/usePoliceSightings";
import { PoliceSightingLayer } from "./PoliceSightingLayer";
import { RiderLayer } from "./RiderLayer";
import { TakeOffButton } from "./TakeOffButton";
import { useRideStatusThresholds } from "@/lib/hooks/useRideStatusThresholds";
import { SS_TOKENS } from "@/lib/tokens";
import {
  THEME_CHANGE_EVENT,
  THEME_STORAGE_KEY,
  readStoredDarkTheme,
} from "@/lib/theme";
import { isVisibleFlight } from "@/lib/aircraft-freshness";
import { computeStatus, type StatusKind } from "@/lib/status";
import { RadarLayerControls } from "./RadarLayerControls";
import { AircraftTrailLayer } from "./AircraftTrailLayer";
import { hasAircraftMapPosition } from "@/lib/map-aircraft";
import {
  aircraftColorForTail,
} from "@/lib/aircraft-colors";
import { LogoMark } from "./brand/Logo";
import {
  FLIGHT_PATHS_VISIBLE_KEY,
  LAYER_VISIBILITY_CHANGE_EVENT,
} from "@/lib/radar-layer-events";
import { Tooltip } from "./Tooltip";
import {
  STATE_CHANGE_EVENT,
  getAppState,
  getSelectedStateCode,
  setAutomaticallyDetectedStateCode,
  shouldAutomaticallyDetectState,
  type StateCode,
} from "@/lib/app-states";
import { PlaneIcon } from "./PlaneIcon";
import { HelicopterIcon } from "./HelicopterIcon";
import type { Aircraft, FleetEntry, Snapshot } from "@/lib/types";

export type RiderPos = { lat: number; lon: number; heading?: number | null };

const RadarMap = nextDynamic(() => import("./RadarMap"), {
  ssr: false,
  loading: () => (
    <div
      style={{
        position: "absolute",
        inset: 0,
        background: SS_TOKENS.bg0,
      }}
    />
  ),
});

const MAP_BOTTOM_INSET = 18;
const GLASS_BG_STRONG = SS_TOKENS.surface;

type Props = {
  initial: Snapshot;
  mockOn?: boolean;
  initialFocusTail?: string;
};

export function RadarShell({
  initial,
  mockOn = false,
  initialFocusTail,
}: Props) {
  const snap = useAircraft(initial, mockOn);
  const plan = usePro();
  const nationwideEnabled = useNationwideMapEnabled() && plan.pro && !mockOn;
  const nationwide = useNationwideMapAircraft(nationwideEnabled);
  const mapAircraft = useMemo(() => (nationwideEnabled
    ? mergeMapAircraft(snap.aircraft, nationwide.aircraft)
    : snap.aircraft.filter(isVisibleFlight)).filter(hasAircraftMapPosition), [nationwideEnabled, snap.aircraft, nationwide.aircraft]);
  const policeSightings = usePoliceSightings(!mockOn);
  const rideThresholds = useRideStatusThresholds();
  const fleetMap = useMemo(
    () => new Map<string, FleetEntry>(snap.aircraft.map((a) => [a.tail, a])),
    [snap.aircraft],
  );
  const status = useMemo(() => computeStatus(snap, fleetMap), [snap, fleetMap]);
  const airborne = useMemo(
    () => snap.aircraft.filter((a) => a.airborne),
    [snap.aircraft],
  );

  const visibleFlights = useMemo(() => snap.aircraft.filter(isVisibleFlight), [snap.aircraft]);

  const [openingCamera] = useState(getMapOpeningCamera);
  const [rider, setRider] = useState<RiderPos | null>(null);
  const [toast, setToast] = useState<string | null>(null);
  const [map, setMap] = useState<MaplibreMap | null>(null);
  const [showRings, setShowRings] = useState(false);
  const [showFlightPaths, setShowFlightPaths] = useState(false);
  const [selectedTail, setSelectedTail] = useState<string | null>(null);
  const [darkMode, setDarkMode] = useState(true);
  const [stateCode, setStateCode] = useState<StateCode>(
    () => getSelectedStateCode(),
  );
  const [focusRequest, setFocusRequest] = useState<{
    tail: string;
    seq: number;
  } | null>(
    initialFocusTail
      ? { tail: initialFocusTail, seq: 1 }
      : null,
  );
  const [riderFocusRequest, setRiderFocusRequest] = useState(0);
  const focusSeqRef = useRef(initialFocusTail ? 1 : 0);
  const automaticStateLookupAttemptedRef = useRef(false);
  useEffect(() => {
    if (typeof document === "undefined") return;
    document.body.dataset.radarMode = "true";
    return () => {
      delete document.body.dataset.radarMode;
    };
  }, []);
  // Hydrate the rings preference and selected state on mount.
  useEffect(() => {
    if (typeof window === "undefined") return;
    setShowRings(window.localStorage.getItem("oos_distance_rings_visible") === "1");
    setShowFlightPaths(
      window.localStorage.getItem(FLIGHT_PATHS_VISIBLE_KEY) === "1",
    );
    setDarkMode(readStoredDarkTheme());
    setStateCode(getSelectedStateCode());
    const onChange = (e: Event) => {
      const detail = (e as CustomEvent<{ code?: StateCode }>).detail;
      setStateCode(detail?.code ?? getSelectedStateCode());
    };
    const onThemeChange = (e: Event) => {
      const detail = (e as CustomEvent<{ dark?: boolean }>).detail;
      setDarkMode(detail?.dark ?? readStoredDarkTheme());
    };
    const onStorage = (e: StorageEvent) => {
      if (e.key === THEME_STORAGE_KEY) {
        setDarkMode(readStoredDarkTheme());
      } else if (e.key === FLIGHT_PATHS_VISIBLE_KEY) {
        setShowFlightPaths(e.newValue === "1");
      }
    };
    window.addEventListener(STATE_CHANGE_EVENT, onChange);
    window.addEventListener(THEME_CHANGE_EVENT, onThemeChange);
    window.addEventListener("storage", onStorage);
    return () => {
      window.removeEventListener(STATE_CHANGE_EVENT, onChange);
      window.removeEventListener(THEME_CHANGE_EVENT, onThemeChange);
      window.removeEventListener("storage", onStorage);
    };
  }, []);
  useEffect(() => {
    if (typeof window === "undefined") return;
    window.localStorage.setItem(
      "oos_distance_rings_visible",
      showRings ? "1" : "0",
    );
  }, [showRings]);
  // Geolocation only kicks in when this component mounts â€” i.e. when the user
  // actually visits /map. The home page never asks.
  useEffect(() => {
    return watchDevicePosition(
      (pos) => {
        const lat = pos.coords.latitude;
        const lon = pos.coords.longitude;
        setRider({ lat, lon, heading: pos.coords.heading });
        void setAutomaticallyDetectedCaliforniaRegion(lat, lon)
          .catch(() => { /* Retry on the next location fix. */ });
        if (
          !automaticStateLookupAttemptedRef.current &&
          shouldAutomaticallyDetectState()
        ) {
          automaticStateLookupAttemptedRef.current = true;
          void fetch("/api/location-state", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ lat, lon }),
          })
            .then(async (response) => {
              if (!response.ok) return null;
              return response.json() as Promise<{ stateCode?: StateCode }>;
            })
            .then(async (result) => {
              if (result?.stateCode) {
                await setAutomaticallyDetectedStateCode(result.stateCode);
                await setAutomaticallyDetectedCaliforniaRegion(lat, lon);
              }
            })
            .catch(() => {
              // The default state remains available when lookup is offline.
            });
        }
      },
      () => {
        flashToast(setToast, "Location off · map still works");
      },
      { enableHighAccuracy: true, maximumAge: 5000, timeout: 15000 },
    );
  }, []);

  useEffect(() => {
    if (!map) return;
    const ready = () => {
      if (map.isMoving()) return;
      map.off("render", ready);
      window.dispatchEvent(new Event("oos:map-ready"));
    };
    map.on("render", ready);
    map.triggerRepaint();
    return () => { map.off("render", ready); };
  }, [map]);

  return (
    <main
      className="ss-map-screen"
      style={{
        position: "fixed",
        inset: 0,
        paddingBottom: MAP_BOTTOM_INSET,
        background: SS_TOKENS.bg0,
      }}
    >
      <RadarMap
        initialCamera={openingCamera}
        aircraft={mapAircraft}
        rider={rider}
        showDistanceRings={showRings}
        distanceRingThresholds={rideThresholds}
        showAltitude
        darkMode={darkMode}
        stateCode={stateCode}
        focusRequest={focusRequest}
        riderFocusRequest={riderFocusRequest}
        onMapReady={setMap}
        onSelectedTailChange={setSelectedTail}
      />
      <MapHeadingCone map={map} rider={rider} />
      <PoliceSightingLayer map={map} sightings={policeSightings} interactive />
      <RiderLayer map={map} enabled={!mockOn} />
      <RadarLayerControls
        ringsActive={showRings}
        onToggleRings={() => setShowRings((v) => !v)}
        ringsDisabled={!rider}
        flightPathsEnabled={plan.pro && showFlightPaths}
        onToggleFlightPaths={() => {
          if (!plan.pro) { openPro("paths"); return; }
          const next = !showFlightPaths;
          setShowFlightPaths(next);
          window.localStorage.setItem(
            FLIGHT_PATHS_VISIBLE_KEY,
            next ? "1" : "0",
          );
          window.dispatchEvent(
            new CustomEvent(LAYER_VISIBILITY_CHANGE_EVENT, {
              detail: { key: FLIGHT_PATHS_VISIBLE_KEY, enabled: next },
            }),
          );
        }}
        onReturnToLocation={() => setRiderFocusRequest((seq) => seq + 1)}
        locationDisabled={!rider || !map}
      />
      <TakeOffButton
        variant="map"
        style={{
          position: "absolute",
          right: "max(14px, env(safe-area-inset-right, 0px))",
          bottom:
            "calc(var(--ss-map-control-bottom, 18px) + var(--ss-install-prompt-h, 0px))",
          zIndex: 13,
          width: 72,
          height: 72,
          padding: 0,
          borderRadius: "50%",
          background: SS_TOKENS.alert,
          border: 0,
          color: "#050505",
          boxShadow:
            "0 9px 20px rgba(0, 0, 0, 0.78), 0 26px 50px rgba(0, 0, 0, 0.68)",
          display: "inline-flex",
          alignItems: "center",
          justifyContent: "center",
          touchAction: "manipulation",
          WebkitTapHighlightColor: "transparent",
        }}
      >
        <span
          style={{
            width: 36,
            height: 36,
            display: "inline-flex",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <MapRideIcon />
        </span>
      </TakeOffButton>
      {plan.pro && <AircraftTrailLayer
        map={map}
        airborne={mapAircraft}
        enabled={showFlightPaths}
        selectedTail={selectedTail}
      />}

      <MapHeader
        airborne={visibleFlights}
        kind={status.kind}
        onSelect={(tail) => {
          focusSeqRef.current += 1;
          setFocusRequest({ tail, seq: focusSeqRef.current });
        }}
      />

      {(toast || nationwide.error) && <Toast message={(toast || nationwide.error)!} bottomBoost={0} />}
    </main>
  );
}

function MapRideIcon() {
  return (
    <svg
      width="34"
      height="34"
      viewBox="0 0 24 24"
      fill="currentColor"
      aria-hidden
      style={{
        display: "block",
        overflow: "visible",
        filter:
          "drop-shadow(0 1px 1px rgba(0, 0, 0, 0.48)) drop-shadow(0 3px 2px rgba(0, 0, 0, 0.24))",
      }}
    >
      <path
        d="m21 3-7.1 18-3.5-7.4L3 10.1 21 3Z"
        transform="translate(-1.25 1.25)"
      />
    </svg>
  );
}

function MapHeader({
  airborne,
  kind,
  onSelect,
}: {
  airborne: Aircraft[];
  kind: StatusKind;
  onSelect: (tail: string) => void;
}) {
  const isAlert = kind === "alert";
  const visibleAircraft = airborne;

  return (
    <header
      className="ss-map-header"
      role="status"
      aria-live="polite"
      aria-label={
        airborne.length === 0
          ? "Aircraft map"
          : `${airborne.length} aircraft on the map`
      }
      style={{
        position: "absolute",
        top: 0,
        left: 0,
        right: 0,
        zIndex: 16,
        background:
          "linear-gradient(to bottom, rgba(0, 0, 0, 0.96) 0%, rgba(0, 0, 0, 0.88) 58%, rgba(0, 0, 0, 0.42) 82%, rgba(0, 0, 0, 0) 100%)",
        color: "#ffffff",
        boxShadow: "0 10px 24px rgba(0, 0, 0, 0.14)",
        backdropFilter: "blur(18px) saturate(1.08)",
        WebkitBackdropFilter: "blur(18px) saturate(1.08)",
        fontFamily: "var(--font-header-ui)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
      }}
    >
      <div
        style={{
          width: "100%",
          maxWidth: "var(--ss-map-header-width, 560px)",
          margin: "0 auto",
          height: "calc(env(safe-area-inset-top, 0px) + var(--ss-map-header-height, clamp(78px, 20vw, 92px)))",
          padding: "env(safe-area-inset-top, 0px) max(18px, env(safe-area-inset-right, 0px)) 10px max(18px, env(safe-area-inset-left, 0px))",
          display: "grid",
          gridTemplateColumns:
            visibleAircraft.length > 0 ? "auto minmax(0, 1fr)" : "1fr auto 1fr",
          alignItems: "center",
          gap: "clamp(12px, 3.8vw, 18px)",
        }}
      >
        <Link
          href="/home"
          aria-label="Home"
          style={{
            justifySelf: "start",
            marginLeft: "clamp(4px, 1.5vw, 8px)",
            display: "block",
            lineHeight: 0,
          }}
        >
          <LogoMark
            height="clamp(36px, 9vw, 48px)"
            width="clamp(54px, 13.5vw, 72px)"
            variant={isAlert ? "open" : "closed"}
          />
        </Link>
        {visibleAircraft.length > 0 && (
          <nav
            aria-label="Aircraft"
            className="ss-scroll"
            style={{
              minHeight: 42,
              display: "flex",
              alignItems: "center",
              gap: 7,
              overflowX: "auto",
              paddingBottom: 1,
              WebkitOverflowScrolling: "touch",
            }}
          >
            {visibleAircraft.map((aircraft) => (
              <MapHeaderAircraftButton
                key={aircraft.tail}
                aircraft={aircraft}
                onSelect={onSelect}
              />
            ))}
          </nav>
        )}
      </div>
    </header>
  );
}

function MapHeaderAircraftButton({
  aircraft,
  onSelect,
}: {
  aircraft: Aircraft;
  onSelect: (tail: string) => void;
}) {
  const color = aircraftColorForTail(aircraft.tail);
  const isHelicopter = aircraft.role === "patrol" || aircraft.role === "sar";
  const displayName = aircraft.tail;
  const ariaLabel = `Center ${displayName} on the map`;

  return (
    <Tooltip content={displayName}>
      <button
        type="button"
        onClick={() => onSelect(aircraft.tail)}
        aria-label={ariaLabel}
        style={{
          flex: "0 0 auto",
          width: 36,
          height: 32,
          padding: 0,
          borderRadius: 8,
          border: `1.5px solid ${color}`,
          background: "rgba(255, 255, 255, 0.08)",
          color,
          boxShadow: `0 0 0 3px ${color}1f, 0 10px 22px rgba(0, 0, 0, 0.28)`,
          cursor: "pointer",
          display: "inline-flex",
          alignItems: "center",
          justifyContent: "center",
          touchAction: "manipulation",
          WebkitTapHighlightColor: "transparent",
        }}
      >
        {isHelicopter ? (
          <HelicopterIcon
            size={29}
            heading={aircraft.heading ?? 0}
          />
        ) : (
          <PlaneIcon
            size={23}
            role={aircraft.role}
            heading={aircraft.heading ?? 0}
            tone="radar"
            color={color}
          />
        )}
      </button>
    </Tooltip>
  );
}

function flashToast(
  setter: (msg: string | null) => void,
  message: string,
  durationMs = 4000,
) {
  setter(message);
  setTimeout(() => setter(null), durationMs);
}

function Toast({
  message,
  bottomBoost,
}: {
  message: string;
  bottomBoost: number;
}) {
  // Sit just above whatever's currently anchored to the bottom â€” carousel
  // when present, tab bar otherwise.
  const bottomOffset = MAP_BOTTOM_INSET + 16 + bottomBoost;
  return (
    <div
      role="status"
      style={{
        position: "absolute",
        left: "50%",
        transform: "translateX(-50%)",
        bottom: bottomOffset,
        padding: "8px 14px",
        borderRadius: 999,
        background: GLASS_BG_STRONG,
        border: `.5px solid ${SS_TOKENS.hairline}`,
        boxShadow: SS_TOKENS.shadowMd,
        color: SS_TOKENS.fg2,
        fontFamily: "inherit",
        fontSize: 11,
        zIndex: 20,
        whiteSpace: "nowrap",
      }}
    >
      {message}
    </div>
  );
}

function AirborneBubbles({
  airborne,
  onSelect,
}: {
  airborne: Aircraft[];
  onSelect: (tail: string) => void;
}) {
  return (
    <nav
      aria-label="Airborne aircraft"
      className="ss-scroll"
      style={{
        position: "absolute",
        left: 10,
        top: "50%",
        transform: "translateY(-50%)",
        zIndex: 14,
        display: "flex",
        flexDirection: "column",
        alignItems: "flex-start",
        gap: 8,
        maxHeight: "calc(100dvh - 220px)",
        overflowY: "auto",
        padding: "4px 2px",
        WebkitOverflowScrolling: "touch",
      }}
    >
      {airborne.map((p) => {
        const color = aircraftColorForTail(p.tail);
        return (
          <Tooltip
            key={p.tail}
            side="right"
            content={`Center ${p.tail} on the map`}
          >
            <button
              type="button"
              onClick={() => onSelect(p.tail)}
              aria-label={`Center ${p.tail} on the map`}
              className="ss-mono"
              style={{
                flex: "0 0 auto",
                width: 62,
                height: 62,
                borderRadius: "50%",
                background: SS_TOKENS.surface,
                border: `1.5px solid ${color}`,
                boxShadow: SS_TOKENS.shadowMd,
                color: SS_TOKENS.fg0,
                display: "inline-flex",
                flexDirection: "column",
                alignItems: "center",
                justifyContent: "center",
                gap: 2,
                fontSize: 9.5,
                fontWeight: 800,
                lineHeight: 1,
                cursor: "pointer",
                touchAction: "manipulation",
                WebkitTapHighlightColor: "transparent",
              }}
            >
              <span
                aria-hidden
                style={{
                  width: 8,
                  height: 8,
                  borderRadius: "50%",
                  background: color,
                  boxShadow: `0 0 0 4px ${color}22`,
                  animation: "ss-blink 1.6s infinite",
                }}
              />
              <span>{p.tail}</span>
              {p.ground_speed_kt != null && (
                <span style={{ color: SS_TOKENS.fg2, fontSize: 8.5 }}>
                  {p.ground_speed_kt}kt
                </span>
              )}
            </button>
          </Tooltip>
        );
      })}
    </nav>
  );
}

function Carousel({
  airborne,
  collapsed,
  onToggleCollapsed,
}: {
  airborne: Aircraft[];
  collapsed: boolean;
  onToggleCollapsed: () => void;
}) {
  if (collapsed) {
    return (
      <Tooltip side="top" align="start" content="Show airborne aircraft cards">
        <button
          type="button"
          onClick={onToggleCollapsed}
          aria-expanded={false}
          aria-label="Show airborne aircraft cards"
          className="ss-mono"
          style={{
            position: "absolute",
            left: 12,
            bottom: `calc(${MAP_BOTTOM_INSET + 16}px + var(--ss-install-prompt-h, 0px))`,
            zIndex: 14,
            width: 56,
            height: 56,
            borderRadius: "50%",
            border: `.5px solid ${SS_TOKENS.hairline2}`,
            background: "rgba(255,255,255,0.92)",
            color: SS_TOKENS.alert,
            boxShadow: SS_TOKENS.shadowMd,
            backdropFilter: "blur(20px)",
            WebkitBackdropFilter: "blur(20px)",
            cursor: "pointer",
            display: "inline-flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "center",
            gap: 1,
            touchAction: "manipulation",
            WebkitTapHighlightColor: "transparent",
          }}
        >
          <span style={{ fontSize: 17, fontWeight: 800, lineHeight: 1 }}>
            {airborne.length}
          </span>
          <span style={{ fontSize: 9, fontWeight: 800, lineHeight: 1 }}>
            UP
          </span>
        </button>
      </Tooltip>
    );
  }

  return (
    <div
      style={{
        position: "absolute",
        left: 0,
        right: 0,
        bottom: MAP_BOTTOM_INSET,
        padding: collapsed ? "10px 14px 12px" : "14px 14px 18px",
        background: "rgba(255,255,255,0.88)",
        borderTop: `.5px solid ${SS_TOKENS.hairline}`,
        borderRadius: "18px 18px 0 0",
        boxShadow: SS_TOKENS.shadowLg,
        backdropFilter: "blur(24px) saturate(1.12)",
        WebkitBackdropFilter: "blur(24px) saturate(1.12)",
        zIndex: 10,
      }}
    >
      <div
        className="ss-eyebrow"
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          gap: 12,
          marginBottom: collapsed ? 0 : 10,
          paddingLeft: 2,
          color: SS_TOKENS.fg1,
        }}
      >
        Airborne
        <Tooltip
          side="top"
          align="end"
          content={collapsed ? "Show airborne cards" : "Collapse airborne cards"}
        >
          <button
            type="button"
            onClick={onToggleCollapsed}
            aria-expanded={!collapsed}
            aria-label={
              collapsed
                ? "Show airborne aircraft cards"
                : "Collapse airborne aircraft cards"
            }
            className="ss-mono"
            style={{
              width: 32,
              height: 32,
              borderRadius: "50%",
              border: `.5px solid ${SS_TOKENS.hairline2}`,
              background: "rgba(255,255,255,0.92)",
              color: SS_TOKENS.fg1,
              boxShadow: SS_TOKENS.shadowSm,
              cursor: "pointer",
              display: "inline-flex",
              alignItems: "center",
              justifyContent: "center",
              fontSize: 0,
              fontWeight: 800,
              lineHeight: 1,
              touchAction: "manipulation",
              WebkitTapHighlightColor: "transparent",
            }}
          >
            <span style={{ fontSize: 16 }}>v</span>
            {collapsed ? "âŒƒ" : "âŒ„"}
          </button>
        </Tooltip>
      </div>
      {!collapsed && (
        <div
          className="ss-scroll"
          style={{
            display: "flex",
            gap: 10,
            overflowX: "auto",
            // Allow cards to bleed into right edge; iOS smooth scroll.
            WebkitOverflowScrolling: "touch",
          }}
        >
          {airborne.map((p) => (
            <PlaneCard key={p.tail} p={p} />
          ))}
        </div>
      )}
    </div>
  );
}

function PlaneCard({ p }: { p: Aircraft }) {
  return (
    <Link
      href={`/plane/${p.tail}`}
      prefetch={false}
      style={{
        flex: "0 0 auto",
        minWidth: 200,
        padding: 14,
        borderRadius: 20,
        background: "rgba(255,255,255,0.94)",
        border: `.5px solid ${SS_TOKENS.hairline}`,
        boxShadow: SS_TOKENS.shadowSm,
        textDecoration: "none",
        color: "inherit",
      }}
    >
      <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
        <span
          style={{
            width: 6,
            height: 6,
            borderRadius: "50%",
            background: SS_TOKENS.alert,
            animation: "ss-blink 1.6s infinite",
          }}
        />
        <span
          className="ss-mono"
          style={{ fontSize: 13, fontWeight: 600, color: SS_TOKENS.fg0 }}
        >
          {p.tail}
        </span>
      </div>
      <div style={{ fontSize: 11, color: SS_TOKENS.fg2, marginTop: 5 }}>
        {p.operator}
      </div>
      <div style={{ display: "flex", gap: 12, marginTop: 8 }}>
        <Stat
          label="ALT"
          value={
            p.altitude_ft != null
              ? `${p.altitude_ft.toLocaleString()}â€²`
              : "â€”"
          }
        />
        <Stat
          label="GS"
          value={p.ground_speed_kt != null ? `${p.ground_speed_kt}kt` : "â€”"}
        />
        <Stat
          label="TIME"
          value={p.time_aloft_min != null ? `${p.time_aloft_min}m` : "â€”"}
        />
      </div>
    </Link>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <div
        className="ss-mono"
        style={{
          fontSize: 9.5,
          color: SS_TOKENS.fg2,
          letterSpacing: ".08em",
        }}
      >
        {label}
      </div>
      <div
        className="ss-mono"
        style={{
          fontSize: 12,
          fontWeight: 600,
          color: SS_TOKENS.fg0,
          marginTop: 1,
        }}
      >
        {value}
      </div>
    </div>
  );
}
