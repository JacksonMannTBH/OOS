"use client";

import { LogoMark } from "@/components/brand/Logo";
import Link from "next/link";
import { usePathname, useSearchParams } from "next/navigation";
import { Suspense } from "react";
import { isVisibleFlight } from "@/lib/aircraft-freshness";
import {
  EMPTY_AIRCRAFT_SNAPSHOT,
  useAircraft,
} from "@/lib/hooks/useAircraft";

export function SiteHeader() {
  const pathname = usePathname();
  const settingsFamilyRoutes = [
    "/help",
    "/aircraft",
    "/plane",
    "/about",
    "/legal",
    "/store",
  ];
  const fadesIntoContent =
    pathname === "/settings" ||
    pathname.startsWith("/settings/") ||
    settingsFamilyRoutes.some(
      (route) => pathname === route || pathname.startsWith(`${route}/`),
    );
  const hidden =
    pathname === "/" ||
    pathname === "/home" ||
    pathname === "/map" ||
    pathname === "/ride" ||
    pathname.startsWith("/map/") ||
    pathname.startsWith("/admin");

  if (hidden) return null;

  return (
    <header
      className="ss-site-header"
      style={{
        width: "100%",
        position: "sticky",
        top: 0,
        zIndex: 48,
        fontFamily: "var(--font-header-ui)",
        background: fadesIntoContent
          ? "linear-gradient(to bottom, rgba(0, 0, 0, 0.96) 0%, rgba(0, 0, 0, 0.88) 58%, rgba(0, 0, 0, 0.42) 82%, rgba(0, 0, 0, 0) 100%)"
          : "#000000",
        color: "#ffffff",
        borderBottom: fadesIntoContent
          ? "none"
          : "0.5px solid rgba(244, 196, 48, 0.34)",
        boxShadow: fadesIntoContent
          ? "0 10px 24px rgba(0, 0, 0, 0.14)"
          : "none",
        backdropFilter: fadesIntoContent
          ? "blur(18px) saturate(1.08)"
          : undefined,
        WebkitBackdropFilter: fadesIntoContent
          ? "blur(18px) saturate(1.08)"
          : undefined,
      }}
    >
      <div
        className="ss-site-header-inner"
        style={{
          maxWidth: "var(--ss-site-header-width, 560px)",
          margin: "0 auto",
          height: "calc(env(safe-area-inset-top, 0px) + var(--ss-site-header-height, clamp(80px, 20vw, 104px)))",
          padding: "env(safe-area-inset-top, 0px) max(18px, env(safe-area-inset-right, 0px)) 0 max(18px, env(safe-area-inset-left, 0px))",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        <div
          style={{
            width: "100%",
            display: "grid",
            gridTemplateColumns: "1fr auto 1fr",
            alignItems: "center",
            color: "inherit",
          }}
        >
          <Link
            href="/home"
            prefetch={false}
            aria-label="Home"
            style={{
              justifySelf: "start",
              color: "inherit",
              textDecoration: "none",
              WebkitTapHighlightColor: "transparent",
            }}
          >
            <Suspense fallback={<HeaderLogoMark variant="closed" />}>
              <HeaderAircraftLogo />
            </Suspense>
          </Link>
          {pathname === "/settings" ? (
            <h1 style={{
              margin: 0,
              fontFamily: "var(--font-header-ui)",
              fontSize: "clamp(28px, 6.4vw, 38px)",
              fontWeight: 800,
              lineHeight: 1,
              letterSpacing: 0,
              whiteSpace: "nowrap",
              textAlign: "center",
            }}>Settings</h1>
          ) : <Link
            href="/home"
            prefetch={false}
            aria-label="Out Of Sight home"
            style={{
              fontFamily: "var(--font-header-brand)",
              fontSize: "clamp(28px, 6.4vw, 38px)",
              fontWeight: 800,
              lineHeight: 1,
              letterSpacing: 0,
              whiteSpace: "nowrap",
              textAlign: "center",
              color: "inherit",
              textDecoration: "none",
              WebkitTapHighlightColor: "transparent",
            }}
          >
            OUT OF SIGHT
          </Link>}
        </div>
      </div>
    </header>
  );
}

function HeaderAircraftLogo() {
  const mockState = useSearchParams().get("mock");
  const mockHasAirborneAircraft =
    mockState === "down"
      ? false
      : mockState === "up" ||
          mockState === "fixed_wing" ||
          mockState === "eyes-up" ||
          mockState === "mixed" ||
          mockState === "multiple"
        ? true
        : null;
  if (mockHasAirborneAircraft != null) {
    return (
      <HeaderLogoMark
        variant={mockHasAirborneAircraft ? "open" : "closed"}
      />
    );
  }

  return <LiveHeaderAircraftLogo />;
}

function LiveHeaderAircraftLogo() {
  const snapshot = useAircraft(EMPTY_AIRCRAFT_SNAPSHOT);
  const hasAirborneAircraft = snapshot.aircraft.some(isVisibleFlight);

  return (
    <HeaderLogoMark
      variant={hasAirborneAircraft ? "open" : "closed"}
    />
  );
}

function HeaderLogoMark({ variant }: { variant: "open" | "closed" }) {
  return (
    <LogoMark
      height="clamp(30px, 7.6vw, 42px)"
      width="clamp(45px, 11.4vw, 63px)"
      variant={variant}
      style={{
        justifySelf: "start",
      }}
    />
  );
}
