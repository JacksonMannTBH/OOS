import { DEFAULT_STATE_CODE, isSupportedStateCode, type StateCode } from "@/lib/app-states";
import { getCatalog } from "@/lib/aircraft-data";
import { liveDataHeaders } from "@/lib/http-cache";
import { getCurrentFlightTrack } from "@/lib/tracks";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type LineFeature = GeoJSON.Feature<
  GeoJSON.LineString,
  { tail: string; count: number }
>;

export async function GET(req: Request) {
  const url = new URL(req.url);
  const requestedState = url.searchParams.get("state");
  const stateCode = isSupportedStateCode(requestedState)
    ? requestedState.toUpperCase() as StateCode
    : DEFAULT_STATE_CODE;
  const requestedTails = parseTails(url.searchParams.get("tails"));
  const catalog = await getCatalog(stateCode);
  const allowed = requestedTails.length
    ? catalog.filter((entry) => requestedTails.includes(entry.tail))
    : catalog;

  const nowMs = Date.now();
  const features = (
    await Promise.all(
      allowed.map(async (entry): Promise<LineFeature | null> => {
        const track = await getCurrentFlightTrack(entry.tail, nowMs);
        const points = track?.points ?? [];
        if (points.length < 2) return null;
        return {
          type: "Feature",
          geometry: {
            type: "LineString",
            coordinates: points.map((point) => [point.lon, point.lat]),
          },
          properties: { tail: entry.tail, count: points.length },
        };
      }),
    )
  ).filter((feature): feature is LineFeature => feature !== null);

  return Response.json(
    {
      type: "FeatureCollection",
      features,
      state: stateCode,
    },
    {
      headers: liveDataHeaders("query=state|tails"),
    },
  );
}

function parseTails(raw: string | null): string[] {
  if (!raw) return [];
  return raw
    .split(",")
    .map((tail) => tail.trim().toUpperCase())
    .filter((tail) => /^[A-Z0-9]{2,12}$/.test(tail))
    .slice(0, 100);
}
