import { SettingsPageShell } from "@/components/SettingsPageShell";
import type { ReactNode } from "react";

export const metadata = {
  title: "Legal & Privacy",
  description: "How Out Of Sight handles safety, privacy, and third-party data.",
};

export const dynamic = "force-static";

const PROVIDERS = [
  {
    name: "FAA Aircraft Registry",
    detail: "Public aircraft registration and ownership records",
    href: "https://www.faa.gov/licenses_certificates/aircraft_certification/aircraft_registry/releasable_aircraft_download",
  },
  {
    name: "ADSB.lol",
    detail: "Aircraft observations · ODbL 1.0",
    href: "https://www.adsb.lol/docs/open-data/",
  },
  {
    name: "OpenFreeMap",
    detail: "Map tiles and styles",
    href: "https://openfreemap.org/privacy/",
  },
] as const;

export default function LegalPage() {
  return (
    <SettingsPageShell
      title="Legal & privacy"
    >
      <LegalSection id="safety" title="Use it safely">
        <p>
          Out Of Sight is an independent hobby project. It is not an official
          aviation feed, navigation aid, traffic service, collision-warning
          system, emergency service, or law-enforcement dispatch tool.
        </p>
        <p>
          Aircraft observations can be late, incomplete, blocked, duplicated,
          or wrong. A missing aircraft does not prove the sky is clear. Flight
          paths, takeoff alerts, headings, speeds, and status labels can also be
          delayed or unavailable.
        </p>
        <p>
          Fuel and endurance displays are estimates based on elapsed time and
          published performance assumptions—not onboard telemetry. Never make a
          safety, travel, or legal decision based only on this app. Do not view
          or operate it while doing so would be unsafe or unlawful.
        </p>
      </LegalSection>

      <LegalSection id="privacy" title="What the app handles">
        <p>
          <strong>Effective November 15, 2026.</strong> Out Of Sight is operated
          by Jackson Mann. For privacy questions or deletion requests, email{" "}
          <a href="mailto:jacksonmann253@gmail.com">
            jacksonmann253@gmail.com
          </a>
          .
        </p>
        <PrivacyRow title="Live location">
          If you allow location access, your coordinates, speed, and heading are
          used on your device for map positioning, distance calculations, and
          Ride Mode. These features keep your location on the device unless you
          explicitly enable Elite rider sharing, described below. If you have not chosen a state,
          the map sends one location fix through our server to the U.S. Census
          geocoder to identify your state. Map tile requests also reveal the
          area being viewed to the map provider. These services may retain
          request logs under their own privacy policies.
        </PrivacyRow>
        <PrivacyRow title="Police sightings">
          Checking nearby sightings with the report button or submitting a report
          sends your current location to our server and the U.S. Census geocoder
          to identify the state. New reports and Still Here confirmations share
          their location and time with users viewing the same state. Not Seen votes
          help remove sightings. A separate random device identifier prevents repeat
          votes; only its hash is stored, and it is never shown to other users.
          Sightings expire 30 minutes after the latest positive confirmation.
          Reports and votes are retained for that sighting’s lifetime, or for 30
          minutes after early removal, then deleted by the next minute’s cleanup.
          Simply viewing map sightings does not upload your location. Reporting
          does not upload your route history.
        </PrivacyRow>
        <PrivacyRow title="Ride recording on iPhone">
          After you confirm recording, Start Ride uses Precise Location to record
          speed, estimated distance, and duration, including while locked or using
          another app. End Ride stops this recording and saves a summary. Your three
          latest summaries are stored only on this phone, excluded from iCloud backup.
          Completing another ride
          replaces the oldest of the three. Route points are saved only on this phone
          to display your route, start, and finish. Route history is not uploaded. Missing distance is not estimated
          when recording is interrupted. Aircraft Live Tracking is a separate session.
        </PrivacyRow>
        <PrivacyRow title="Elite rider sharing">
          If you enable map visibility in Elite Settings, your precise current
          location, username and chosen icon are sent to our server during an
          active recorded ride and shown to other OOS users, including while your
          screen is locked. Speed is included only when you enable speed sharing.
          Only the latest shared position is stored; your recorded route is not
          uploaded. End Ride or turning visibility off removes the active position.
          If the phone loses its connection, the position disappears within 45
          seconds and is deleted by the next minute’s cleanup. Profiles and sharing
          choices are saved for this installation with a random private credential.
          There is no login, account recovery or profile transfer to another phone.
          Reset preferences turns sharing off and keeps your saved username and icon.
        </PrivacyRow>
        <PrivacyRow title="Live tracking on iPhone">
          Turning on Live tracking starts a location session that continues while
          you use other apps or lock your phone. Your device calculates the nearest
          tracked aircraft, distance, and ride state and shows them in a Live
          Activity. Your coordinates are not sent with aircraft-data requests.
          Tap Stop Live Tracking on Home to end this session. An active ride can
          continue recording until you tap End Ride.
          Ending Ride Mode does not stop Live tracking. If location or aircraft data
          expires, the activity keeps its last known state, aircraft, distance, and
          original update time until fresh data becomes available.
        </PrivacyRow>
        <PrivacyRow title="Home Screen widget on iPhone">
          With location permission, the widget calculates aircraft distances on
          your device when iOS refreshes it. The app and widget share your selected
          state, aircraft preferences, distance bands, and last calculated result
          in private storage on your phone. Your coordinates stay in memory and
          are not saved there or sent with aircraft-data requests. The widget
          works independently of Live tracking and keeps its last known result
          and update time when new data is unavailable.
        </PrivacyRow>
        <PrivacyRow title="Takeoff alerts">
          Enabling alerts stores a random device ID, selected state, aircraft
          preferences, and either browser push details or a Firebase messaging
          token for the mobile app. Google Firebase and, on iPhone, Apple Push
          Notification service deliver mobile alerts. Alert subscriptions do not
          include your location or speed. Turning alerts off stops registration
          for notifications and deletes the server subscription.
        </PrivacyRow>
        <PrivacyRow title="Preferences">
          Local storage and first-party cookies remember choices such as state,
          time format, contrast, Ride Mode distances, and dismissed prompts on
          this device. Use “Reset preferences” in Display &amp; Time to clear them.
        </PrivacyRow>
        <PrivacyRow title="Routine requests">
          Hosting, database, push, and map providers receive the technical data
          normally sent with web requests, such as IP address, browser details,
          time, and requested resource. Map requests can reveal the area being
          viewed. Those providers apply their own privacy terms. Firebase also collects
          SDK diagnostic and technical metadata to operate and improve its
          services. Notification delivery records are associated with your
          device subscription. We do not use this data for advertising or
          cross-app advertising tracking.
        </PrivacyRow>
        <PrivacyRow title="Retention and deletion">
          Any location reports submitted before reporting was discontinued
          remain subject to the seven-day retention and scheduled deletion
          policy. Turning off takeoff alerts deletes the associated push
          subscription from Out Of Sight. Preferences stored on the device can
          be removed with “Reset preferences” in Display &amp; Time. To request
          deletion of other data that may be associated with you, email the
          privacy contact above with enough detail to identify the relevant
          record, such as its approximate date and time. Data may be retained
          longer only when reasonably necessary for security, abuse prevention,
          or legal compliance.
        </PrivacyRow>
      </LegalSection>

      <LegalSection id="terms" title="Terms of use">
        <LegalClause title="Your agreement">
          By accessing or using Out Of Sight, you agree to these terms. If you do
          not agree, do not use the service.
        </LegalClause>
        <LegalClause title="Permitted use">
          The service is offered for lawful, personal, non-commercial,
          informational use. You may not use it to harm or endanger anyone,
          facilitate unlawful conduct, interfere with aircraft or communications,
          disrupt the service, bypass access controls, or redistribute third-party
          data in violation of its provider’s terms.
        </LegalClause>
        <LegalClause title="Availability and changes">
          Features, coverage, providers, aircraft records, and the service itself
          may change, pause, or end without notice. Access may be limited when
          needed to protect the service or comply with law or provider terms.
        </LegalClause>
        <LegalClause title="No warranties">
          The service and its information are provided “as is” and “as
          available.” To the fullest extent allowed by law, no warranty is made
          about accuracy, completeness, timeliness, availability, fitness for a
          particular purpose, or non-infringement.
        </LegalClause>
        <LegalClause title="Limits on liability">
          To the fullest extent allowed by law, the project operator,
          maintainers, and contributors are not liable for injury, property
          damage, citations, penalties, data loss, or other damages arising from
          access to, use of, inability to use, or reliance on the service.
        </LegalClause>
      </LegalSection>

      <LegalSection id="sources" title="Aircraft data & maps">
        <p>
          Aircraft observations come from ADSB.lol under the Open Database
          License (ODbL) 1.0. Aircraft registration and ownership
          details are derived primarily from the FAA Releasable Aircraft
          Database. Supplemental public agency records may help resolve
          ambiguous registrations. Out Of Sight has no access to private agency
          systems or official operational feeds.
        </p>
        <div className="ss-legal-providers">
          {PROVIDERS.map((provider) => (
            <a key={provider.name} href={provider.href} target="_blank" rel="noopener noreferrer">
              <span>
                <strong>{provider.name}</strong>
                <small>{provider.detail}</small>
              </span>
              <span aria-hidden>↗</span>
            </a>
          ))}
        </div>
        <p className="ss-legal-fine-print">
          Third-party services control their own availability, accuracy, terms,
          and privacy practices. Out Of Sight is an independent app. It is not
          affiliated with, endorsed by, or operated by the FAA or any federal,
          state, county, or local government agency, data provider, aircraft
          operator, or manufacturer.
        </p>
        <p className="ss-legal-fine-print">
          OpenSky attribution: Schäfer et al., <cite>Bringing Up OpenSky: A
          Large-scale ADS-B Sensor Network for Research</cite>, IPSN 2014.
        </p>
      </LegalSection>

    </SettingsPageShell>
  );
}

function LegalSection({ id, title, children }: { id: string; title: string; children: ReactNode }) {
  return (
    <section id={id} className="ss-legal-section" aria-labelledby={`${id}-title`}>
      <header><h2 id={`${id}-title`}>{title}</h2></header>
      <div className="ss-legal-section__body">{children}</div>
    </section>
  );
}

function PrivacyRow({ title, children }: { title: string; children: ReactNode }) {
  return (
    <div className="ss-legal-privacy-row">
      <h3>{title}</h3>
      <p>{children}</p>
    </div>
  );
}

function LegalClause({ title, children }: { title: string; children: ReactNode }) {
  return <div className="ss-legal-clause"><h3>{title}</h3><p>{children}</p></div>;
}
