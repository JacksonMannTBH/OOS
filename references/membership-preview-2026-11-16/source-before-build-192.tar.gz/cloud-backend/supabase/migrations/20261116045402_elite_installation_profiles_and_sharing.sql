-- Installation capabilities only. No auth.users, email, login or recovery links.
create sequence public.oos_rider_revision;
create table public.oos_rider_profiles (
  id uuid primary key default gen_random_uuid(),
  owner_hash text not null unique check (owner_hash ~ '^[a-f0-9]{64}$'),
  registration_bucket text,
  username text check (username ~ '^[a-zA-Z0-9_]{1,20}$'),
  icon text not null default 'eye',
  visible boolean not null default false,
  share_speed boolean not null default false,
  elite_until timestamptz,
  active_session uuid,
  last_session uuid,
  ended_sessions uuid[] not null default '{}',
  last_sequence bigint not null default 0,
  last_captured_at timestamptz,
  last_heartbeat_at timestamptz,
  created_at timestamptz not null default now()
);
create unique index oos_rider_unique_username on public.oos_rider_profiles (lower(username)) where username is not null;
create index oos_rider_registration_time on public.oos_rider_profiles(created_at);
create index oos_rider_registration_bucket on public.oos_rider_profiles(registration_bucket,created_at);
create table public.oos_rider_presence (
  profile_id uuid primary key references public.oos_rider_profiles(id) on delete cascade,
  lat double precision not null check (lat between -90 and 90),
  lon double precision not null check (lon between -180 and 180),
  speed_mps double precision check (speed_mps between 0 and 150),
  heading double precision check (heading >= 0 and heading < 360),
  captured_at timestamptz not null,
  expires_at timestamptz not null,
  version bigint not null,
  topic text not null
);
create index oos_rider_presence_expiry on public.oos_rider_presence(expires_at);
create index oos_rider_presence_area on public.oos_rider_presence(topic, expires_at);
alter table public.oos_rider_profiles enable row level security;
alter table public.oos_rider_presence enable row level security;
revoke all on public.oos_rider_profiles, public.oos_rider_presence from public, anon, authenticated;
grant all on public.oos_rider_profiles, public.oos_rider_presence to service_role;
grant usage, select on sequence public.oos_rider_revision to service_role;
create policy rider_profiles_server_only on public.oos_rider_profiles to service_role using (true) with check (true);
create policy rider_presence_server_only on public.oos_rider_presence to service_role using (true) with check (true);

-- Viewer access matches the existing "everyone's map" product behavior. No
-- INSERT policy: clients cannot inject locations on the receive-only topics.
create policy oos_riders_receive on realtime.messages for select to anon, authenticated
using (extension = 'broadcast' and (select realtime.topic()) ~ '^oos-riders:([0-9]|[1-8][0-9]):([0-9]|[1-9][0-9]|1[0-7][0-9])$');

create function public.oos_rider_card(p_id uuid) returns jsonb language sql stable security invoker set search_path = '' as $$
  select jsonb_strip_nulls(jsonb_build_object(
    'id', p.id, 'username', p.username, 'icon', p.icon, 'lat', r.lat, 'lon', r.lon,
    'speedMps', case when p.share_speed then r.speed_mps end, 'heading', r.heading,
    'capturedAt', extract(epoch from r.captured_at) * 1000,
    'expiresAt', extract(epoch from least(r.expires_at,p.elite_until)) * 1000, 'version', r.version))
  from public.oos_rider_presence r join public.oos_rider_profiles p on p.id = r.profile_id
  where p.id = p_id and p.visible and p.username is not null and p.active_session is not null and p.elite_until > now() and r.expires_at > now();
$$;
create function public.oos_rider_private_profile(p_id uuid) returns jsonb language sql stable security invoker set search_path = '' as $$
  select jsonb_build_object('id', id, 'username', coalesce(username,''), 'icon', icon, 'visible', visible,
    'shareSpeed', share_speed, 'elite', coalesce(elite_until > now(),false),
    'eliteUntil', extract(epoch from elite_until)*1000, 'activeSession', active_session)
  from public.oos_rider_profiles where id = p_id;
$$;
create function public.oos_rider_remove(p_id uuid) returns jsonb language plpgsql security invoker set search_path = '' as $$
declare r public.oos_rider_presence;
begin
  delete from public.oos_rider_presence where profile_id=p_id returning * into r;
  if r.profile_id is null then return '[]'::jsonb; end if;
  return jsonb_build_array(jsonb_build_object('topic',r.topic,'payload',jsonb_build_object('id',p_id,'version',nextval('public.oos_rider_revision'))));
end;
$$;
create function public.oos_rider_read(p_bounds jsonb) returns jsonb language plpgsql stable security invoker set search_path = '' as $$
declare w double precision := (p_bounds->>'west')::double precision;
  e double precision := (p_bounds->>'east')::double precision;
  s double precision := (p_bounds->>'south')::double precision;
  n double precision := (p_bounds->>'north')::double precision;
  cards jsonb;
begin
  if w is null or e is null or s is null or n is null or w < -180 or e > 180 or s < -90 or n > 90 or w >= e or s >= n or e-w > 8.001 or n-s > 8.001 then raise exception 'invalid_bounds'; end if;
  select coalesce(jsonb_agg(card),'[]'::jsonb) into cards from (
    select public.oos_rider_card(r.profile_id) card from public.oos_rider_presence r
    join public.oos_rider_profiles p on p.id = r.profile_id
    where r.lat between s and n and r.lon between w and e and r.expires_at > now()
      and p.visible and p.elite_until > now() and p.active_session is not null and p.username is not null
    order by r.version desc limit 200
  ) bounded;
  return jsonb_build_object('riders',cards,'serverTime',extract(epoch from now())*1000);
end;
$$;

create function public.oos_rider_command(p_owner text, p_action text, p_body jsonb default '{}'::jsonb) returns jsonb
language plpgsql security invoker set search_path = '' as $$
declare p public.oos_rider_profiles;
  previous public.oos_rider_presence;
  events jsonb := '[]'::jsonb;
  v_session uuid;
  v_captured timestamptz;
  v_version bigint;
  v_topic text;
  v_card jsonb;
begin
  if p_owner is null or p_owner !~ '^[a-f0-9]{64}$' then return jsonb_build_object('result',jsonb_build_object('error','invalid_installation')); end if;
  -- Serialize registration and updates for this installation, including End Ride.
  perform pg_advisory_xact_lock(hashtextextended('oos-rider:'||p_owner,0));
  if p_action='register' then
    if not exists(select 1 from public.oos_rider_profiles where owner_hash=p_owner) then
      perform pg_advisory_xact_lock(hashtextextended('oos-rider-registration',0));
      if (select count(*) from public.oos_rider_profiles where created_at > now()-interval '1 hour') >= 10000 or
        (select count(*) from public.oos_rider_profiles where registration_bucket=p_body->>'registrationBucket' and created_at > now()-interval '1 hour') >= 30 then
        return jsonb_build_object('result',jsonb_build_object('error','rate_limited'));
      end if;
      insert into public.oos_rider_profiles(owner_hash,registration_bucket) values(p_owner,p_body->>'registrationBucket');
    end if;
  end if;
  select * into p from public.oos_rider_profiles where owner_hash=p_owner for update;
  if p.id is null then return jsonb_build_object('result',jsonb_build_object('error','installation_missing')); end if;
  if p_action='profile' or p_action='register' then
    return jsonb_build_object('result',jsonb_build_object('profile',public.oos_rider_private_profile(p.id)));
  end if;
  if p_action='delete' then
    events := public.oos_rider_remove(p.id);
    delete from public.oos_rider_profiles where id=p.id;
    return jsonb_build_object('result',jsonb_build_object('deleted',true),'events',events);
  end if;
  if p_action='stop' then
    v_session:=(p_body->>'session')::uuid;
    if not v_session=any(p.ended_sessions) then
      update public.oos_rider_profiles set ended_sessions=(array_append(ended_sessions,v_session))[greatest(1,cardinality(ended_sessions)-30):] where id=p.id;
    end if;
    if p.active_session=(p_body->>'session')::uuid then
      update public.oos_rider_profiles set active_session=null where id=p.id;
      events := public.oos_rider_remove(p.id);
    end if;
    return jsonb_build_object('result',jsonb_build_object('stopped',true),'events',events);
  end if;
  if p_action='update' then
    if exists(select 1 from jsonb_object_keys(p_body) k where k not in ('username','icon','visible','shareSpeed')) then raise exception 'invalid_profile'; end if;
    if p_body ? 'username' and (p_body->>'username' is null or p_body->>'username' !~ '^[a-zA-Z0-9_]{1,20}$') then raise exception 'invalid_profile'; end if;
    if p_body ? 'icon' and (p_body->>'icon' is null or p_body->>'icon' not in ('eye','radioactive','skull','middle-finger','black-joker-cards','strawberry','pistol-filled','dagger-knife-small','broken-heart-filled','face-with-no-good-gesture','game-die','cat-face','ghost','gem-stone','slightly-smiling-face','boy-filled','cherry-blossom','cherries-filled','birthday-cake','crown')) then raise exception 'invalid_profile'; end if;
    if (p_body ? 'visible' and jsonb_typeof(p_body->'visible') <> 'boolean') or (p_body ? 'shareSpeed' and jsonb_typeof(p_body->'shareSpeed') <> 'boolean') then raise exception 'invalid_profile'; end if;
    -- Privacy switches remain usable after expiry. Access is never supplied by JS.
    if coalesce(p.elite_until <= now(),true) and (p_body ? 'username' or p_body ? 'icon' or p_body->>'visible'='true' or p_body->>'shareSpeed'='true') then
      return jsonb_build_object('result',jsonb_build_object('error','elite_required'));
    end if;
    update public.oos_rider_profiles set username=coalesce(p_body->>'username',username), icon=coalesce(p_body->>'icon',icon),
      visible=coalesce((p_body->>'visible')::boolean,visible), share_speed=coalesce((p_body->>'shareSpeed')::boolean,share_speed),
      active_session=case when p_body->>'visible'='false' then null else active_session end where id=p.id returning * into p;
    if not p.visible then events:=public.oos_rider_remove(p.id);
    else
      update public.oos_rider_presence set speed_mps=case when p.share_speed then speed_mps end,version=nextval('public.oos_rider_revision') where profile_id=p.id;
      v_card:=public.oos_rider_card(p.id);
      if v_card is not null then
        select topic into v_topic from public.oos_rider_presence where profile_id=p.id;
        events:=jsonb_build_array(jsonb_build_object('topic',v_topic,'payload',jsonb_build_object('id',p.id,'version',(v_card->>'version')::bigint,'rider',v_card)));
      end if;
    end if;
    return jsonb_build_object('result',jsonb_build_object('profile',public.oos_rider_private_profile(p.id)),'events',events);
  end if;
  if coalesce(p.elite_until <= now(),true) then return jsonb_build_object('result',jsonb_build_object('error','elite_required')); end if;
  if not p.visible or p.username is null then return jsonb_build_object('result',jsonb_build_object('error','sharing_disabled')); end if;
  v_session := (p_body->>'session')::uuid;
  if p_action='start' then
    if p.active_session=v_session then return jsonb_build_object('result',jsonb_build_object('session',v_session)); end if;
    if p.last_session=v_session or v_session=any(p.ended_sessions) then return jsonb_build_object('result',jsonb_build_object('error','session_ended')); end if;
    events:=public.oos_rider_remove(p.id);
    update public.oos_rider_profiles set active_session=v_session,last_session=v_session,last_sequence=0,last_captured_at=null,last_heartbeat_at=null where id=p.id;
    return jsonb_build_object('result',jsonb_build_object('session',v_session),'events',events);
  end if;
  if p_action <> 'heartbeat' then raise exception 'invalid_action'; end if;
  if p.active_session is distinct from v_session then return jsonb_build_object('result',jsonb_build_object('error','session_ended')); end if;
  v_captured:=to_timestamp((p_body->>'capturedAt')::double precision/1000);
  if v_captured is null or v_captured < now()-interval '15 seconds' or v_captured > now()+interval '5 seconds' or
    (p_body->>'accuracy')::double precision not between 0 and 100 or
    (p_body->>'lat')::double precision not between -90 and 90 or (p_body->>'lon')::double precision not between -180 and 180 then raise exception 'fresh_location_required'; end if;
  if (p_body->>'sequence')::bigint <= p.last_sequence or v_captured <= p.last_captured_at then return jsonb_build_object('result',jsonb_build_object('ignored',true)); end if;
  if p.last_heartbeat_at > now()-interval '3 seconds' then return jsonb_build_object('result',jsonb_build_object('error','rate_limited')); end if;
  select * into previous from public.oos_rider_presence where profile_id=p.id;
  v_topic:='oos-riders:'||least(89,floor(((p_body->>'lat')::double precision+90)/2)::integer)||':'||least(179,floor(((p_body->>'lon')::double precision+180)/2)::integer);
  if previous.topic is not null and previous.topic<>v_topic then events:=public.oos_rider_remove(p.id); end if;
  v_version:=nextval('public.oos_rider_revision');
  insert into public.oos_rider_presence(profile_id,lat,lon,speed_mps,heading,captured_at,expires_at,version,topic)
    values(p.id,(p_body->>'lat')::double precision,(p_body->>'lon')::double precision,
      case when p.share_speed then (p_body->>'speedMps')::double precision end,(p_body->>'heading')::double precision,
      v_captured,least(now()+interval '45 seconds',v_captured+interval '45 seconds',p.elite_until),v_version,v_topic)
  on conflict(profile_id) do update set lat=excluded.lat,lon=excluded.lon,speed_mps=excluded.speed_mps,heading=excluded.heading,
    captured_at=excluded.captured_at,expires_at=excluded.expires_at,version=excluded.version,topic=excluded.topic;
  update public.oos_rider_profiles set last_sequence=(p_body->>'sequence')::bigint,last_captured_at=v_captured,last_heartbeat_at=now() where id=p.id;
  v_card:=public.oos_rider_card(p.id);
  events:=events||jsonb_build_array(jsonb_build_object('topic',v_topic,'payload',jsonb_build_object('id',p.id,'version',v_version,'rider',v_card)));
  return jsonb_build_object('result',jsonb_build_object('expiresAt',v_card->'expiresAt'),'events',events);
exception when unique_violation then return jsonb_build_object('result',jsonb_build_object('error','username_taken'));
end;
$$;

-- Immediate removal on an administrative revoke. Only tombstones go through
-- database broadcast; coordinates use ephemeral REST broadcast, with no replay.
create function public.oos_rider_revoke() returns trigger language plpgsql security invoker set search_path = '' as $$
declare event jsonb;
begin
  if new.elite_until is distinct from old.elite_until and coalesce(new.elite_until <= now(),true) then
    new.active_session:=null;
    for event in select * from jsonb_array_elements(public.oos_rider_remove(old.id)) loop
      perform realtime.send(event->'payload','rider',event->>'topic',true);
    end loop;
  end if;
  return new;
end;
$$;
create trigger oos_rider_membership_revoke before update of elite_until on public.oos_rider_profiles for each row execute function public.oos_rider_revoke();
create function public.oos_rider_cleanup() returns void language plpgsql security invoker set search_path = '' as $$
declare item record; event jsonb;
begin
  -- Same profile lock order as writes. Never retain a trail of shared positions.
  for item in select p.id from public.oos_rider_profiles p join public.oos_rider_presence r on r.profile_id=p.id
    where r.expires_at <= now() or p.elite_until <= now() or not p.visible for update of p skip locked loop
    for event in select * from jsonb_array_elements(public.oos_rider_remove(item.id)) loop
      perform realtime.send(event->'payload','rider',event->>'topic',true);
    end loop;
  end loop;
end;
$$;
do $$ declare fn record; begin
  for fn in select oid::regprocedure signature from pg_proc where pronamespace='public'::regnamespace and proname like 'oos_rider_%' loop
    execute format('revoke all on function %s from public, anon, authenticated',fn.signature);
    execute format('grant execute on function %s to service_role',fn.signature);
  end loop;
end $$;
select cron.schedule('oos-riders-cleanup','* * * * *','select public.oos_rider_cleanup()');
