import assert from "node:assert/strict";
import { test } from "node:test";
import { createRidersHandler, riderTokenHash } from "../src/riders-handler";
import { RiderCollection, riderTopic, riderTopics, type SharedRider } from "../../lib/rider-sharing";

const key="sb_publishable_test", token="1".repeat(64), now=1_800_000_000_000;
const headers={apikey:key,authorization:`Bearer ${token}`,"content-type":"application/json"};
const url="https://example.supabase.co/functions/v1/oos-riders/";
function handler(rpc: (name:string,args:Record<string,unknown>)=>Promise<Record<string,unknown>> = async()=>({result:{ok:true}}), broadcast=async (_events:unknown[])=>{}) {
  return createRidersHandler(name=>name==="SUPABASE_PUBLISHABLE_KEYS"?JSON.stringify({default:key}):"server-test-secret",rpc,broadcast,()=>now);
}
const call=(path:string,method="GET",body?:unknown,h:Record<string,string>=headers)=>new Request(url+path,{method,headers:h,body:body===undefined?undefined:JSON.stringify(body)});
test("rider API requires app key and installation capability before private operations",async()=>{
  let calls=0;const run=handler(async()=>{calls++;return {result:{ok:true}};});
  assert.equal((await run(call("profile","GET",undefined,{apikey:"wrong"}))).status,401);
  assert.equal((await run(call("profile","GET",undefined,{apikey:key}))).status,401);
  assert.equal((await run(call("profile","GET",undefined,{...headers,origin:"https://evil.example"}))).status,403);
  assert.equal(calls,0);
  const preflight=await run(call("profile","OPTIONS",undefined,{origin:"capacitor://localhost"}));
  assert.equal(preflight.status,204);assert.match(preflight.headers.get("Access-Control-Allow-Headers")!,/authorization/);
});
test("ownership is derived from a hashed secret and cannot be selected with a profile ID",async()=>{
  const run=handler(async(name,args)=>{
    assert.equal(name,"oos_rider_command");assert.equal(args.p_owner,await riderTokenHash(token));assert.notEqual(args.p_owner,token);
    return {result:{profile:{id:"own-profile"}},events:[]};
  });
  const response=await run(call("profile","POST",{id:"someone-else",elite:true}));
  assert.equal(response.status,200);assert.equal((await response.json()).profile.id,"own-profile");
});
test("membership fields, malformed profiles and oversized bodies are rejected",async()=>{
  let calls=0;const run=handler(async()=>{calls++;return {result:{}};});
  for(const body of [{elite:true},{eliteUntil:now+1000},{username:"bad name"},{icon:"<svg>"},{visible:"true"},[]])assert.equal((await run(call("profile","PATCH",body))).status,400);
  assert.equal((await run(call("profile","PATCH",{username:"a".repeat(3000)}))).status,413);
  assert.equal(calls,0);
});
test("map reads are bounded and do not require paid membership",async()=>{
  const run=handler(async(name,args)=>{assert.equal(name,"oos_rider_read");assert.deepEqual(args.p_bounds,{west:-123,east:-121,south:36,north:38});return {riders:[],serverTime:now};});
  assert.equal((await run(call("riders?west=-123&east=-121&south=36&north=38","GET",undefined,{apikey:key}))).status,200);
  for(const query of ["","west=-180&east=180&south=-90&north=90","west=NaN&east=0&south=0&north=1","west=1&east=0&south=0&north=1"])assert.equal((await run(call("riders?"+query))).status,400);
});
test("heartbeats reject stale locations, invalid sessions and impossible speeds",async()=>{
  const good={session:"11111111-1111-4111-8111-111111111111",sequence:1,lat:37,lon:-122,accuracy:10,capturedAt:now,speedMps:10};
  const run=handler();
  assert.equal((await run(call("presence","POST",good))).status,200);
  for(const changes of [{capturedAt:now-16000},{capturedAt:now+6000},{accuracy:101},{lon:181},{speedMps:151},{sequence:0},{session:"invalid"}])assert.equal((await run(call("presence","POST",{...good,...changes}))).status,400);
});
test("privacy writes remain successful when realtime delivery fails",async()=>{
  const run=handler(async()=>({result:{profile:{visible:false}},events:[{payload:{id:"x",version:2}}]}),async()=>{throw new Error("offline");});
  const response=await run(call("profile","PATCH",{visible:false}));assert.equal(response.status,200);assert.equal((await response.json()).profile.visible,false);
  assert.equal(response.headers.get("Cache-Control"),"no-store");
});
test("database access and validation errors have useful response codes",async()=>{
  for(const [error,status] of [["elite_required",403],["username_taken",409],["rate_limited",429],["installation_missing",401],["session_ended",400]] as const){const run=handler(async()=>({result:{error}}));assert.equal((await run(call("profile"))).status,status);}
});
const rider=(id:string,version:number,speed=true):SharedRider=>({id,version,username:"Rider_1",icon:"eye",lat:37,lon:-122,capturedAt:now,expiresAt:now+45000,...speed?{speedMps:12}:{}});
test("two rider feed removes speed and ignores delayed updates after hiding or ending",()=>{
  const a=rider("11111111-1111-4111-8111-111111111111",1),b=rider("22222222-2222-4222-8222-222222222222",2);
  const collection=new RiderCollection();
  collection.accept({id:a.id,version:1,rider:a});collection.accept({id:b.id,version:2,rider:b});assert.equal(collection.list(now).length,2);
  const hiddenSpeed=rider(a.id,3,false);collection.accept({id:a.id,version:3,rider:hiddenSpeed});assert.equal(collection.list(now).find(r=>r.id===a.id)?.speedMps,undefined);
  collection.accept({id:a.id,version:4});assert.equal(collection.accept({id:a.id,version:1,rider:a}),false);assert.equal(collection.list(now).length,1);
  assert.equal(collection.list(now+45001).length,0);
});
test("feed rejects malformed broadcasts and bounds room count",()=>{
  const c=new RiderCollection(),r=rider("11111111-1111-4111-8111-111111111111",1);
  assert.equal(c.accept({id:r.id,version:1,rider:{...r,icon:"untrusted"}}),false);
  assert.equal(c.accept({id:r.id,version:1,rider:{...r,speedMps:-1}}),false);
  assert.equal(riderTopic(37,-122),"oos-riders:63:29");
  assert(riderTopics({west:-124,east:-116,south:34,north:42}).length<=25);
});
