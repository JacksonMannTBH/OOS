import { validRiderBounds, validRiderIcon, validRiderUsername, type RiderBounds } from "../../lib/rider-sharing";
type Env = (name: string) => string | undefined;
type Rpc = (name: string, args: Record<string, unknown>) => Promise<Record<string, unknown>>;
type Broadcast = (events: unknown[]) => Promise<void>;
const uuid = (v: unknown) => typeof v === "string" && /^[a-f0-9]{8}-[a-f0-9]{4}-[1-5][a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/i.test(v);
export async function riderTokenHash(token: string): Promise<string> {
  return Array.from(new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(token))), b => b.toString(16).padStart(2, "0")).join("");
}
export function createRidersHandler(env: Env, rpc: Rpc, broadcast: Broadcast, now = Date.now) {
  return async (request: Request): Promise<Response> => {
    const headers = new Headers({ "Cache-Control": "no-store", Vary: "Origin" });
    const reply = (value: unknown, status = 200) => Response.json(value, { status, headers });
    const origin = request.headers.get("origin");
    if (origin && !["capacitor://localhost", "https://localhost", "http://localhost", "http://localhost:5173", "http://localhost:3000", "https://outofsight.live", "https://www.outofsight.live"].includes(origin)) return reply({ error: "origin_not_allowed" }, 403);
    if (origin) headers.set("Access-Control-Allow-Origin", origin);
    headers.set("Access-Control-Allow-Headers", "apikey, authorization, content-type");
    headers.set("Access-Control-Allow-Methods", "GET, POST, PATCH, DELETE, OPTIONS");
    if (request.method === "OPTIONS") return new Response(null, { status: 204, headers });
    let keys: unknown;
    try { keys = JSON.parse(env("SUPABASE_PUBLISHABLE_KEYS") ?? "{}"); } catch { return reply({ error: "unavailable" }, 503); }
    if (!keys || typeof keys !== "object" || !Object.values(keys).some(k => typeof k === "string" && k.startsWith("sb_publishable_") && k === request.headers.get("apikey"))) return reply({ error: "invalid_client_key" }, 401);
    const url = new URL(request.url);
    const path = url.pathname.replace(/^\/(?:functions\/v1\/)?oos-riders\/?/, "");
    try {
      if (request.method === "GET" && path === "riders") {
        const names = ["west", "south", "east", "north"] as const;
        if (names.some(n => !url.searchParams.has(n))) return reply({ error: "invalid_bounds" }, 400);
        const bounds = Object.fromEntries(names.map(n => [n, Number(url.searchParams.get(n))])) as RiderBounds;
        if (!validRiderBounds(bounds)) return reply({ error: "invalid_bounds" }, 400);
        return reply(await rpc("oos_rider_read", { p_bounds: bounds }));
      }
      const action = ({ "POST profile": "register", "GET profile": "profile", "PATCH profile": "update", "POST presence/start": "start", "POST presence": "heartbeat", "DELETE presence": "stop", "DELETE profile": "delete" } as Record<string, string>)[`${request.method} ${path}`];
      if (!action) return reply({ error: "not_found" }, 404);
      const token = request.headers.get("authorization")?.replace(/^Bearer /, "") ?? "";
      if (!/^[a-f0-9]{64}$/.test(token)) return reply({ error: "invalid_installation" }, 401);
      let body: Record<string, unknown> = {};
      if (request.method !== "GET") {
        if (Number(request.headers.get("content-length")) > 2048) return reply({ error: "invalid_request" }, 413);
        const reader = request.body?.getReader();
        let size = 0; const chunks: Uint8Array[] = [];
        if (reader) while (true) { const part = await reader.read(); if (part.done) break; size += part.value.length; if (size > 2048) { await reader.cancel(); return reply({ error: "invalid_request" }, 413); } chunks.push(part.value); }
        try { body = JSON.parse(chunks.map(c => new TextDecoder().decode(c)).join("") || "{}"); } catch { return reply({ error: "invalid_request" }, 400); }
        if (!body || typeof body !== "object" || Array.isArray(body)) return reply({ error: "invalid_request" }, 400);
      }
      if (action === "update") {
        if (Object.keys(body).some(k => !["username", "icon", "visible", "shareSpeed"].includes(k)) ||
          body.username !== undefined && !validRiderUsername(body.username) || body.icon !== undefined && !validRiderIcon(body.icon) ||
          body.visible !== undefined && typeof body.visible !== "boolean" || body.shareSpeed !== undefined && typeof body.shareSpeed !== "boolean") return reply({ error: "invalid_profile" }, 400);
      }
      if (["start", "heartbeat", "stop"].includes(action) && !uuid(body.session)) return reply({ error: "invalid_session" }, 400);
      if (action === "heartbeat") {
        const { lat, lon, accuracy, capturedAt, sequence, speedMps, heading } = body;
        if (typeof lat !== "number" || !Number.isFinite(lat) || lat < -90 || lat > 90 || typeof lon !== "number" || !Number.isFinite(lon) || lon < -180 || lon > 180 ||
          typeof accuracy !== "number" || !Number.isFinite(accuracy) || accuracy < 0 || accuracy > 100 ||
          typeof capturedAt !== "number" || !Number.isFinite(capturedAt) || capturedAt < now() - 15_000 || capturedAt > now() + 5_000 ||
          !Number.isSafeInteger(sequence) || Number(sequence) < 1 || speedMps !== undefined && (typeof speedMps !== "number" || !Number.isFinite(speedMps) || speedMps < 0 || speedMps > 150) ||
          heading !== undefined && (typeof heading !== "number" || !Number.isFinite(heading) || heading < 0 || heading >= 360)) return reply({ error: "fresh_location_required" }, 400);
      }
      if (action === "register") {
        const salt=env("SUPABASE_SERVICE_ROLE_KEY");
        if(!salt)return reply({error:"unavailable"},503);
        // Retain an hourly salted bucket, never the address itself. Client
        // fields cannot choose either this bucket or the membership tier.
        const address=request.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ?? "unknown";
        body={registrationBucket:await riderTokenHash(`${salt}:${Math.floor(now()/3_600_000)}:${address}`)};
      }
      const result = await rpc("oos_rider_command", { p_owner: await riderTokenHash(token), p_action: action, p_body: body });
      const events = Array.isArray(result.events) ? result.events : [];
      // Delivery failure must not roll back a privacy change. Snapshots reconcile it.
      if (events.length) await broadcast(events).catch(() => undefined);
      const data = result.result as Record<string, unknown>;
      const status = data?.error === "username_taken" ? 409 : data?.error === "rate_limited" ? 429 : data?.error === "elite_required" ? 403 : data?.error === "installation_missing" ? 401 : data?.error ? 400 : 200;
      return reply(data, status);
    } catch { return reply({ error: "sharing_unavailable" }, 503); }
  };
}
