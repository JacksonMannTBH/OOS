import { runtime } from "./runtime";
import { createRidersHandler } from "./riders-handler";
const env = (name: string) => runtime.env.get(name);
const serverHeaders = () => ({ "Content-Type": "application/json", apikey: env("SUPABASE_SERVICE_ROLE_KEY") ?? "", Authorization: `Bearer ${env("SUPABASE_SERVICE_ROLE_KEY")}` });
runtime.serve(createRidersHandler(env, async (name, args) => {
  const response = await fetch(`${env("SUPABASE_URL")}/rest/v1/rpc/${name}`, { method: "POST", headers: serverHeaders(), body: JSON.stringify(args), signal: AbortSignal.timeout(8_000) });
  if (!response.ok) throw new Error("rider_database_unavailable");
  return response.json();
}, async events => {
  const response = await fetch(`${env("SUPABASE_URL")}/realtime/v1/api/broadcast`, { method: "POST", headers: serverHeaders(), body: JSON.stringify({ messages: events.map(value => {
    const event = value as { topic: string; payload: unknown };
    return { topic: event.topic, event: "rider", payload: event.payload, private: true };
  }) }), signal: AbortSignal.timeout(5_000) });
  if (!response.ok) throw new Error("rider_broadcast_unavailable");
}));
