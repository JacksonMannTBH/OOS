# Memberships — phone build 160

Build 36's membership work has been integrated into the current app, retaining
newer ride recording, G-force, calibration, sightings, aircraft updates and
rider preferences. Build history is in docs/app-store-submission.md.

Settings has a centered single-line Out Of Sight Membership feature banner.
It opens a dialog with Pro/Elite tabs and clean plan-selection actions.
Pro retains the one-week trial and $4.99/month presentation, with the trial
larger on the left and the price smaller on the right. Elite lists the Pro
features plus rider profile, username, custom icon, visibility and speed-sharing
controls, at $9.99/month. Only the Pro tab shows the Free Trial Week pill.

Choosing Elite persists the native tier and includes Pro access. All plans
show Elite Settings. Free/Pro taps and direct links open the Elite membership
dialog; only Elite opens the settings themselves.
Choosing a different plan preserves saved Elite preferences; the Use Free UI
control has been removed. Existing rides remain
resumable and finishable, and saved history remains accessible. Recent Rides has
no Pro badge and shows five rows at a time, with scrolling to the remaining
saved rides. Stats requires Pro or Elite; Free members opening its menu entry
or direct route see the Pro membership dialog.

The local native membership bridge is Debug-only and supports Free, Pro, Elite
and StoreKit states. Builds without it retain existing Pro-feature access and
no Elite access. Native subscription signing and backend entitlement work remain
separate from this UI task; no backend deployment or App Store submission was
performed. Selecting plans in this build changes the local native membership.

Evidence, source backup and installation verification are in
.local/membership-156/. Focused membership tests, app/mobile type checks and the signed
build passed. The app check excludes the existing unrelated Play Store
simulation error. Chromium and WebKit checks cover four layouts, plan access,
Elite route guards and persisted username, icon and speed settings.

Build 158 removes the Elite Settings shortcut from the membership dialog while
retaining its Settings menu entry. The banner feature reads Rider profiles.
Current visual and installation evidence is in `.local/membership-158/`.

Build 159 removes the separate offer row. Free Trial Week labels the Pro action,
and $9.99/month labels the Elite action. Selected-plan buttons retain their
label while disabled. Current evidence: `.local/membership-159/`.

Build 160 makes Free Trial Week conditional on confirmed native StoreKit
eligibility. Used or unknown eligibility and active memberships show the
monthly price. Development mode does not bypass this check. Seven focused
tests and both browser engines cover these scenarios. Current evidence:
`.local/membership-160/`.

Aircraft name tags keep fixed positions on the full map and Home preview.
Overlapping tags render as complete units in a stable order, with the selected
aircraft's tag on top. Selecting an aircraft cannot mount or show flight
paths for Free members, and downgrading removes existing path layers. Free
members do not see Wake mode, Speedometer, or Lean and Pitch settings. The
G-force information card and individual distance-band descriptions are removed.
Time defaults to 12-hour while explicit saved 24-hour choices remain supported.
The About text uses connected prose without dash punctuation. Verification and
phone installation evidence are in `.local/display-map-166/`.

The membership dialog closes when users tap outside the box and has no Done
button. Inside taps and scrolling keep it open, and Escape still dismisses it.
This backdrop behavior applies to the membership dialog. Build 168 evidence is
in `.local/membership-dialog-168/`.

Build 169 adds fixed-position tag stacking and a flat yellow End Ride button
with a stop icon, pressed feedback and a saving indicator. The button text and
tap behavior are unchanged. Verification is in `.local/tag-stack-end-ride-169/`.
