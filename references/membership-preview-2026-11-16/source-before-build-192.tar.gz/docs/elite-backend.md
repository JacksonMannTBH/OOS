# Elite rider backend

Elite profiles belong to one installation. There are no logins, email addresses,
recoverable accounts, account linking, profile transfers or recovery endpoints.
On iOS the 256-bit capability stays in the native Keychain with
`AfterFirstUnlockThisDeviceOnly` protection. An unbacked installation marker
rotates the capability after reinstall or device migration. Web views never
receive the capability. Browser-only profiles use local browser storage.

## Profile and access

The isolated `oos-riders` Edge Function uses the existing OOS project and public
client configuration. Private operations require both the publishable app key
and an installation bearer capability. The database stores only its SHA-256
hash. Neither a public profile ID nor a locally selected membership tier grants
ownership or Elite access.

Profiles have a case-insensitive unique username (1–20 letters, digits or
underscores), a bundled icon, visibility and speed preferences, and a
server-controlled `elite_until`. New profiles start hidden with speed sharing
off. An explicit confirmation enables visibility. The previous local preview's
name and icon can be imported after activation, without importing its
default-on visibility or speed switches.

Paid billing remains disabled. Approved test installations can be activated by
an administrator setting `elite_until` on the exact installation profile.
The native Debug membership selection additionally controls whether that phone
attempts sharing; it cannot grant backend access. Administrators can revoke
access by setting `elite_until=null`, which removes the active position.
Downgrades retain the saved profile and preferences.

## Sharing

The native ride recorder sends accepted GPS fixes while an active ride,
the locally enabled Elite tier, backend Elite access and visibility all permit
sharing. It reuses the shared background location service and uploads at most
once every five seconds. Samples older than 15 seconds, inaccurate samples,
invalid coordinates and invalid speeds are rejected. An unavailable GPS speed
is omitted; it is never represented as zero.

Only the latest shared position is stored. It expires within 45 seconds, capped
by the subscription access expiry. Clients remove expired markers even offline;
a separate minute cleanup removes expired rows. Ride routes and ride summaries
continue to stay on the device. Ending a ride or hiding the rider deletes the
current position. Sequence numbers, session identifiers, ended-session
tombstones, and serialized native requests protect against delayed updates.
End Ride saves locally even when networking fails, and the sharing lease still
expires. A successful server privacy change stays successful if caching or
Realtime delivery fails.

Native privacy holds take effect before a disable request is sent, persist
across launches, and clear only after an explicit successful enable. Thus a
failed offline save cannot restart visibility or speed sharing on reconnect.
Reset preferences stops rider sharing before clearing local settings and retains
the server profile's username and icon. Help and the in-app privacy text describe
the optional sharing behavior.

Disabling speed sharing clears the stored speed and excludes it from subsequent
snapshots and broadcasts, including delayed requests containing an old speed.
Enabling speed again waits for a new valid location sample.

## Maps and authorization

Home, main and Ride Mode maps show other visible Elite riders at zoom 6 and
closer. All membership levels can view these riders, matching the settings copy.
Each marker opens the username and optional MPH; the selected icon is rendered
from bundled, validated source paths. The current installation's own marker is
excluded.

Reads are bounded to the viewport, at most eight degrees per axis and 200
visible riders. Private receive-only Realtime rooms cover two-degree cells, at
most 25 rooms per viewport. No client INSERT policy is added. Coordinates are
broadcast from the server through ephemeral REST broadcasts and never through
stored database broadcasts or aircraft channels. Database broadcasts contain
only removal tombstones. A bounded 15-second snapshot reconciliation repairs
missed events. Hidden/backgrounded maps unsubscribe.

Both tables have RLS and deny direct anon/authenticated access. All rider RPCs
are invoker functions restricted to the service role. The Edge Function checks
ownership before invoking them. Registration has hourly per-bucket/global
limits; buckets are salted hashes and never store IP addresses.

## API

| Method and path | Result |
| --- | --- |
| POST /profile | Create or load this installation's private profile |
| GET /profile | Load this installation's private profile |
| PATCH /profile | Update username, icon or sharing preferences |
| DELETE /profile | Delete this installation's profile and position |
| POST /presence/start | Start a new sharing session |
| POST /presence | Accept a fresh, ordered location sample |
| DELETE /presence | Stop a specific sharing session |
| GET /riders?west=…&east=…&south=…&north=… | Bounded public map snapshot |

Client-supplied membership, owner IDs or credential hashes are never writable
profile fields. Profile deletion is an authenticated capability operation and
does not permit reclaiming a lost installation.

## Build and verification

`npm run build:riders-backend` builds `.local/cloud-functions/riders.js`.
Deploy that bundle as `oos-riders`, with gateway JWT verification off because
the handler implements its own app-key and installation authentication. Existing
project secrets provide the server credentials; no new secret ships to clients.
The additive migration is in `cloud-backend/supabase/migrations/`.

`npm run test:riders` checks authorization, validation, privacy responses, two
rider merging, stale updates and marker expiry. `cloud-backend/tests/riders.sql`
runs rollback-only PostgreSQL assertions against the actual database functions.
`npm run check:riders-backend` creates and deletes only its own temporary
installation; it never grants access, reserves a username or publishes a location.

The frontend also needs the new native plugin and a rebuilt packaged interface.
Existing installed builds do not start sharing as a result of backend deployment.
The aircraft supplier, ingestion worker and existing schedules are not modified.

## November 15, 2026 verification

The additive schema is applied to the existing OOS project and `oos-riders`
version 1 is active. The rollback-only database assertions pass in both a
disposable PostgreSQL instance and the live project. The live HTTP smoke check
passes and deletes its temporary installation. Live private-channel reception
was verified with a coordinate-free removal event, and anonymous client
broadcast injection was rejected. No test positions were published and no
approved installations remain from verification. Security advisors show no new
findings; the existing notification receipt table's informational notice remains.

All 261 app/backend tests pass. Chromium and WebKit checks run the actual rider
handler and database functions against two isolated native-bridge fixtures,
covering explicit consent, names, icons, optional speed, live hiding and name
conflicts. App and mobile type checks pass when excluding the existing unrelated
Play Store screenshot simulation type error. The packaged iOS simulator Debug
build passes. Physical-device GPS, locked-screen delivery and paid purchases
were not exercised. The frontend changes require installing the updated app;
there was no App Store upload or public website deployment.
